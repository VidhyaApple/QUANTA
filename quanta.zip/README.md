Tracking employee's work and time quanity on a daily basis 
